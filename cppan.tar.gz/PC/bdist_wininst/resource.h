/*
  IMPORTANT NOTE: IF THIS FILE IS CHANGED, PCBUILD\BDIST_WININST.VCXPROJ MUST
  BE REBUILT AS WELL.

  IF CHANGES TO THIS FILE ARE CHECKED IN, THE RECOMPILED BINARIES MUST BE
  CHECKED IN AS WELL!
*/

#define IDD_DIALOG1                     101
#define IDB_BITMAP1                     103
#define IDD_INTRO                       107
#define IDD_SELECTPYTHON                108
#define IDD_INSTALLFILES                109
#define IDD_FINISHED                    110
#define IDB_BITMAP                      110
#define IDC_EDIT1                       1000
#define IDC_TITLE                       1000
#define IDC_START                       1001
#define IDC_PROGRESS                    1003
#define IDC_INFO                        1004
#define IDC_PYTHON15                    1006
#define IDC_PATH                        1007
#define IDC_PYTHON16                    1008
#define IDC_INSTALL_PATH                1008
#define IDC_PYTHON20                    1009
#define IDC_BROWSE                      1010
#define IDC_INTRO_TEXT                  1021
#define IDC_VERSIONS_LIST               1022
#define IDC_BUILD_INFO                  1024
#define IDC_BITMAP                      1025
#define IDC_OTHERPYTHON                 1026
